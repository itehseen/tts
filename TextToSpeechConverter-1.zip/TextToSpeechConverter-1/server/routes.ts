import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { textToSpeechSchema } from "@shared/schema";
import axios from "axios";

export async function registerRoutes(app: Express): Promise<Server> {
  // Text-to-speech API endpoint
  app.post("/api/text-to-speech", async (req, res) => {
    try {
      // Validate request body
      const validatedData = textToSpeechSchema.parse(req.body);
      const { text, voiceId, speed, pitch } = validatedData;

      const API_KEY = process.env.ELEVEN_LABS_API_KEY;
      
      if (!API_KEY) {
        return res.status(500).json({ message: "Eleven Labs API key is not configured" });
      }

      // Call Eleven Labs API
      const response = await axios({
        method: 'post',
        url: `https://api.elevenlabs.io/v1/text-to-speech/${voiceId}`,
        headers: {
          'Accept': 'audio/mpeg',
          'Content-Type': 'application/json',
          'xi-api-key': API_KEY
        },
        data: {
          text,
          model_id: "eleven_monolingual_v1",
          voice_settings: {
            stability: 0.5,
            similarity_boost: 0.5,
            speed: speed,
            pitch: pitch
          }
        },
        responseType: 'arraybuffer'
      });

      // Return audio data
      res.set('Content-Type', 'audio/mpeg');
      res.send(Buffer.from(response.data, 'binary'));
    } catch (error) {
      console.error('Error generating speech:', error);
      if (error.name === 'ZodError') {
        return res.status(400).json({ message: "Invalid request data", details: error.errors });
      }
      
      if (error.response) {
        // Error from Eleven Labs API
        return res.status(error.response.status).json({ 
          message: "Error from text-to-speech service",
          details: error.response.data
        });
      }
      
      res.status(500).json({ message: "Failed to generate speech" });
    }
  });

  // Get available voices
  app.get("/api/voices", async (req, res) => {
    try {
      const API_KEY = process.env.ELEVEN_LABS_API_KEY;
      
      if (!API_KEY) {
        return res.status(500).json({ message: "Eleven Labs API key is not configured" });
      }

      const response = await axios({
        method: 'get',
        url: 'https://api.elevenlabs.io/v1/voices',
        headers: {
          'Accept': 'application/json',
          'xi-api-key': API_KEY
        }
      });

      res.json(response.data);
    } catch (error) {
      console.error('Error fetching voices:', error);
      res.status(500).json({ message: "Failed to fetch available voices" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
