// This file contains functions to interact with the Eleven Labs API via our backend

export interface Voice {
  voice_id: string;
  name: string;
  preview_url: string;
  category?: string;
}

/**
 * Fetches available voices from the Eleven Labs API
 */
export const getVoices = async (): Promise<Voice[]> => {
  const response = await fetch('/api/voices', {
    method: 'GET',
    headers: {
      'Content-Type': 'application/json',
    },
    credentials: 'include',
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Failed to fetch voices');
  }

  const data = await response.json();
  return data.voices || [];
};

/**
 * Generates speech from text using the Eleven Labs API
 */
export const generateSpeech = async (
  text: string,
  voiceId: string,
  speed: number = 1.0,
  pitch: number = 1.0
): Promise<Blob> => {
  const response = await fetch('/api/text-to-speech', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      text,
      voiceId,
      speed,
      pitch,
    }),
    credentials: 'include',
  });

  if (!response.ok) {
    const error = await response.json();
    throw new Error(error.message || 'Failed to generate speech');
  }

  return await response.blob();
};
