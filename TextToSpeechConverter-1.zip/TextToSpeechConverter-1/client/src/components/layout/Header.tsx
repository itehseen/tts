import { Button } from "@/components/ui/button";
import { Drill } from "lucide-react";

const Header = () => {
  return (
    <header className="bg-white shadow-sm py-4">
      <div className="container mx-auto px-4 flex justify-between items-center">
        <a href="/" className="flex items-center gap-2 text-primary font-bold text-xl">
          <Drill className="h-6 w-6" />
          <span>Tools Venture</span>
        </a>
        <a 
          href="https://toolsventure.net/" 
          target="_blank" 
          rel="noopener noreferrer"
          className="group"
        >
          <Button variant="outline" className="group-hover:bg-primary group-hover:text-white transition-colors duration-300">
            <span>More Tools</span>
            <svg 
              xmlns="http://www.w3.org/2000/svg" 
              className="h-4 w-4 ml-2" 
              viewBox="0 0 24 24" 
              fill="none" 
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
            >
              <path d="M5 12h14M12 5l7 7-7 7" />
            </svg>
          </Button>
        </a>
      </div>
    </header>
  );
};

export default Header;
