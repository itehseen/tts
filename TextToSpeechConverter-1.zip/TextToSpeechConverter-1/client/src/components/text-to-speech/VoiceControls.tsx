import { Select, SelectContent, SelectGroup, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { type VoiceSettings } from "@/pages/home";

interface VoiceControlsProps {
  settings: VoiceSettings;
  onSettingsChange: (settings: Partial<VoiceSettings>) => void;
  voices: any[];
}

const VoiceControls = ({ settings, onSettingsChange, voices }: VoiceControlsProps) => {
  return (
    <div className="grid grid-cols-1 gap-6">
      {/* Voice Selection */}
      <div className="space-y-2">
        <Label htmlFor="voice" className="block font-medium text-gray-700">Select Voice</Label>
        <Select
          value={settings.voiceId}
          onValueChange={(value) => onSettingsChange({ voiceId: value })}
        >
          <SelectTrigger className="w-full">
            <SelectValue placeholder="Select a voice" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              {voices.length > 0 ? (
                voices.map((voice) => (
                  <SelectItem key={voice.voice_id} value={voice.voice_id}>
                    {voice.name}
                  </SelectItem>
                ))
              ) : (
                <>
                  <SelectItem value="21m00Tcm4TlvDq8ikWAM">Rachel (Female)</SelectItem>
                  <SelectItem value="AZnzlk1XvdvUeBnXmlld">Domi (Male)</SelectItem>
                  <SelectItem value="EXAVITQu4vr4xnSDxMaL">Bella (Female)</SelectItem>
                  <SelectItem value="MF3mGyEYCl7XYWbV9V6O">Antoni (Male)</SelectItem>
                </>
              )}
            </SelectGroup>
          </SelectContent>
        </Select>
      </div>
    </div>
  );
};

export default VoiceControls;
