import { Card, CardContent } from "@/components/ui/card";
import { BadgeCheck, Sliders, DownloadCloud } from "lucide-react";

const Features = () => {
  return (
    <div className="mt-16">
      <h2 className="text-2xl font-bold text-center mb-8">Why Use Our Text to Speech Converter</h2>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Feature 1 */}
        <Card className="bg-white shadow-sm border border-gray-100">
          <CardContent className="p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <BadgeCheck className="text-xl text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Natural-Sounding Voices</h3>
            <p className="text-gray-600">
              Our advanced AI technology produces natural-sounding speech that's almost 
              indistinguishable from human voices.
            </p>
          </CardContent>
        </Card>
        
        {/* Feature 2 */}
        <Card className="bg-white shadow-sm border border-gray-100">
          <CardContent className="p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <Sliders className="text-xl text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Adjustable Settings</h3>
            <p className="text-gray-600">
              Customize your audio with adjustable speed and pitch controls to create 
              the perfect voice for your needs.
            </p>
          </CardContent>
        </Card>
        
        {/* Feature 3 */}
        <Card className="bg-white shadow-sm border border-gray-100">
          <CardContent className="p-6">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mb-4">
              <DownloadCloud className="text-xl text-primary" />
            </div>
            <h3 className="text-lg font-semibold mb-2">Easy Downloads</h3>
            <p className="text-gray-600">
              Download your generated speech in high-quality audio format for use in your 
              projects, videos, or presentations.
            </p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Features;
