import { useEffect, useRef } from "react";

interface WaveformVisualizerProps {
  isPlaceholder: boolean;
  isPlaying?: boolean;
  progress?: number;
}

const WaveformVisualizer = ({ 
  isPlaceholder, 
  isPlaying = false, 
  progress = 0 
}: WaveformVisualizerProps) => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  
  useEffect(() => {
    if (!canvasRef.current) return;
    
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Set canvas dimensions
    canvas.width = canvas.offsetWidth;
    canvas.height = canvas.offsetHeight;
    
    const drawWaveform = () => {
      if (!ctx) return;
      
      // Clear canvas
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      // Calculate the number of bars
      const barCount = Math.floor(canvas.width / 3);
      const barWidth = 2;
      const barSpacing = 1;
      
      // Draw bars
      for (let i = 0; i < barCount; i++) {
        const x = i * (barWidth + barSpacing);
        
        // Determine if this bar should be "active" based on progress
        const isActive = !isPlaceholder && (x / canvas.width) * 100 <= progress;
        
        // For placeholder, create a static pattern
        // For real visualization, create a random height for each bar
        let barHeight;
        
        if (isPlaceholder) {
          // Create a sine wave pattern for the placeholder
          barHeight = Math.sin(i * 0.1) * 20 + 30;
        } else {
          // For the actual visualization
          // Make the active part more energetic if playing
          if (isActive && isPlaying) {
            barHeight = Math.random() * 50 + 10;
          } else if (isActive) {
            barHeight = Math.random() * 30 + 20;
          } else {
            barHeight = Math.random() * 20 + 10;
          }
        }
        
        // Ensure bar doesn't exceed canvas height
        barHeight = Math.min(barHeight, canvas.height * 0.8);
        
        // Position bar in the middle of canvas height
        const y = (canvas.height - barHeight) / 2;
        
        // Set bar color
        if (isPlaceholder) {
          ctx.fillStyle = 'rgba(107, 114, 128, 0.3)'; // Gray for placeholder
        } else if (isActive) {
          ctx.fillStyle = 'rgba(37, 99, 235, 0.8)'; // Blue for active part
        } else {
          ctx.fillStyle = 'rgba(107, 114, 128, 0.5)'; // Gray for inactive part
        }
        
        // Draw the bar
        ctx.fillRect(x, y, barWidth, barHeight);
      }
    };
    
    drawWaveform();
    
    // If not a placeholder and playing, animate the waveform
    let animationId: number;
    
    if (!isPlaceholder && isPlaying) {
      const animate = () => {
        drawWaveform();
        animationId = requestAnimationFrame(animate);
      };
      
      animate();
    }
    
    // Handle window resize
    const handleResize = () => {
      canvas.width = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
      drawWaveform();
    };
    
    window.addEventListener('resize', handleResize);
    
    return () => {
      window.removeEventListener('resize', handleResize);
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, [isPlaceholder, isPlaying, progress]);
  
  return (
    <canvas 
      ref={canvasRef} 
      className="w-full h-full"
      style={{ 
        opacity: isPlaceholder ? 0.5 : 1,
      }}
    />
  );
};

export default WaveformVisualizer;
