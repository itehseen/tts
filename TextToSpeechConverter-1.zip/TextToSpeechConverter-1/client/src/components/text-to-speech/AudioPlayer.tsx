import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Play, Pause, Download, RefreshCw } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import WaveformVisualizer from "./WaveformVisualizer";

interface AudioPlayerProps {
  audioUrl: string | null;
  onRegenerate: () => void;
  isGenerating: boolean;
}

const AudioPlayer = ({ audioUrl, onRegenerate, isGenerating }: AudioPlayerProps) => {
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const animationRef = useRef<number | null>(null);

  useEffect(() => {
    // Reset state when new audio is generated
    if (audioUrl) {
      setIsPlaying(false);
      setCurrentTime(0);
      
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    }
  }, [audioUrl]);

  const togglePlayPause = () => {
    if (!audioRef.current) return;

    if (isPlaying) {
      audioRef.current.pause();
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    } else {
      audioRef.current.play();
      animationRef.current = requestAnimationFrame(updateProgress);
    }
    
    setIsPlaying(!isPlaying);
  };

  const updateProgress = () => {
    if (!audioRef.current) return;
    
    setCurrentTime(audioRef.current.currentTime);
    
    if (audioRef.current.ended) {
      setIsPlaying(false);
      setCurrentTime(0);
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    } else {
      animationRef.current = requestAnimationFrame(updateProgress);
    }
  };

  const handleDownload = () => {
    if (!audioUrl) return;
    
    const a = document.createElement("a");
    a.href = audioUrl;
    a.download = "text-to-speech.mp3";
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handleLoadedMetadata = () => {
    if (audioRef.current) {
      setDuration(audioRef.current.duration);
    }
  };

  const formatTime = (time: number) => {
    const minutes = Math.floor(time / 60);
    const seconds = Math.floor(time % 60);
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };

  const progressPercentage = duration > 0 ? (currentTime / duration) * 100 : 0;

  return (
    <Card className="bg-white rounded-xl shadow-md">
      <CardContent className="p-6">
        <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
          <svg 
            xmlns="http://www.w3.org/2000/svg" 
            className="h-5 w-5"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M12 12c0-1 1-1 1-2s-1-1-1-2 1-1 1-2-1-1-1-2" />
            <path d="M9 12c0-1 1-1 1-2s-1-1-1-2 1-1 1-2-1-1-1-2" />
            <path d="M15 12c0-1 1-1 1-2s-1-1-1-2 1-1 1-2-1-1-1-2" />
            <path d="M5 10a2 2 0 0 1 2 2c0 1 1 1 1 2s-1 1-1 2a2 2 0 1 1-2-2c0-1-1-1-1-2s1-1 1-2Z" />
            <path d="M19 10a2 2 0 0 0-2 2c0 1-1 1-1 2s1 1 1 2a2 2 0 1 0 2-2c0-1 1-1 1-2s-1-1-1-2Z" />
          </svg>
          <span>Audio Preview</span>
        </h2>

        {!audioUrl ? (
          <div className="flex flex-col items-center justify-center h-64 bg-gray-50 rounded-lg border border-gray-200 mb-6">
            <WaveformVisualizer isPlaceholder={true} />
            <p className="text-gray-500 mt-4">
              {isGenerating ? "Generating speech..." : "Generate speech to see the audio preview"}
            </p>
          </div>
        ) : (
          <div className="flex flex-col space-y-6">
            <div className="relative h-44 bg-gray-50 rounded-lg overflow-hidden">
              <WaveformVisualizer 
                isPlaceholder={false} 
                isPlaying={isPlaying} 
                progress={progressPercentage}
              />
              
              <audio 
                ref={audioRef} 
                src={audioUrl} 
                onLoadedMetadata={handleLoadedMetadata}
                onEnded={() => setIsPlaying(false)}
                className="hidden"
              />
              
              <div className="absolute bottom-0 left-0 right-0 bg-gray-100 bg-opacity-80 p-3">
                <div className="flex items-center gap-3">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={togglePlayPause}
                    className="text-primary text-2xl"
                  >
                    {isPlaying ? (
                      <Pause className="h-6 w-6" />
                    ) : (
                      <Play className="h-6 w-6" />
                    )}
                  </Button>
                  
                  <div className="w-full bg-gray-300 rounded-full h-2 overflow-hidden">
                    <div 
                      className="bg-primary h-2 rounded-full" 
                      style={{ width: `${progressPercentage}%` }}
                    ></div>
                  </div>
                  
                  <span className="text-sm font-medium text-gray-700">
                    {formatTime(currentTime)} / {formatTime(duration)}
                  </span>
                </div>
              </div>
            </div>
            
            <div className="flex flex-col md:flex-row gap-4">
              <Button 
                onClick={handleDownload}
                className="flex-1 bg-blue-600 text-white hover:bg-green-600 transition-colors duration-300"
              >
                <Download className="h-5 w-5 mr-2" />
                <span>Download Audio</span>
              </Button>
              
              <Button 
                onClick={onRegenerate}
                variant="outline"
                className="flex-1 border-primary text-primary hover:bg-gray-50"
              >
                <RefreshCw className="h-5 w-5 mr-2" />
                <span>Regenerate</span>
              </Button>
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default AudioPlayer;
