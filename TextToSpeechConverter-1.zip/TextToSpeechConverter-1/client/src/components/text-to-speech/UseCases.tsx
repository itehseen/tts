import { Video, BookOpen, Mic, ChartGantt } from "lucide-react";

const UseCases = () => {
  return (
    <div className="mt-16 bg-gradient-to-r from-blue-50 to-indigo-50 rounded-2xl p-8">
      <h2 className="text-2xl font-bold text-center mb-6">Popular Use Cases</h2>
      
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
            <Video className="h-5 w-5 text-primary" />
          </div>
          <span className="font-medium">Video Narration</span>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
            <BookOpen className="h-5 w-5 text-primary" />
          </div>
          <span className="font-medium">Audiobooks</span>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
            <Mic className="h-5 w-5 text-primary" />
          </div>
          <span className="font-medium">Podcast Content</span>
        </div>
        
        <div className="bg-white p-4 rounded-lg shadow-sm flex items-center gap-3">
          <div className="w-10 h-10 bg-primary bg-opacity-10 rounded-full flex items-center justify-center">
            <ChartGantt className="h-5 w-5 text-primary" />
          </div>
          <span className="font-medium">Presentations</span>
        </div>
      </div>
    </div>
  );
};

export default UseCases;
