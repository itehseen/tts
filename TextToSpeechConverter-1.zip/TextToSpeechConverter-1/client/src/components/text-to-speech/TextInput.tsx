import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Volume2 } from "lucide-react";
import { Loader2 } from "lucide-react";
import { Text } from "lucide-react";

interface TextInputProps {
  text: string;
  onTextChange: (text: string) => void;
  isGenerating: boolean;
  onGenerate: () => void;
}

const TextInput = ({ text, onTextChange, isGenerating, onGenerate }: TextInputProps) => {
  return (
    <div>
      <h2 className="text-xl font-semibold mb-4 flex items-center gap-2">
        <Text className="h-5 w-5" />
        <span>Enter Your Text</span>
      </h2>
      
      <Textarea
        value={text}
        onChange={(e) => onTextChange(e.target.value)}
        className="w-full h-64 p-4 border border-gray-300 rounded-lg focus:ring-2 focus:ring-primary focus:border-primary resize-none"
        placeholder="Type or paste your text here..."
      />
      
      <Button
        onClick={onGenerate}
        disabled={isGenerating || !text.trim()}
        className="w-full mt-4 bg-primary text-white py-3 px-4 rounded-lg font-medium hover:bg-blue-700 transition duration-300 flex items-center justify-center gap-2"
      >
        {isGenerating ? (
          <>
            <Loader2 className="h-5 w-5 animate-spin" />
            <span>Generating...</span>
          </>
        ) : (
          <>
            <Volume2 className="h-5 w-5" />
            <span>Generate Speech</span>
          </>
        )}
      </Button>
    </div>
  );
};

export default TextInput;
