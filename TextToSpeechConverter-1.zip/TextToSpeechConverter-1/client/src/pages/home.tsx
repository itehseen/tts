import { useState } from "react";
import TextInput from "@/components/text-to-speech/TextInput";
import VoiceControls from "@/components/text-to-speech/VoiceControls";
import AudioPlayer from "@/components/text-to-speech/AudioPlayer";
import Features from "@/components/text-to-speech/Features";
import { useQuery } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { Skeleton } from "@/components/ui/skeleton";

export type VoiceSettings = {
  voiceId: string;
};

const Home = () => {
  const { toast } = useToast();
  const [text, setText] = useState("");
  const [voiceSettings, setVoiceSettings] = useState<VoiceSettings>({
    voiceId: "21m00Tcm4TlvDq8ikWAM", // Default ElevenLabs voice ID
  });
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);

  // Fetch available voices
  const { data: voicesData, isLoading: loadingVoices, error: voicesError } = useQuery<{voices: any[]}>({
    queryKey: ['/api/voices'],
    staleTime: Infinity, // Voices won't change frequently
  });

  // Handle text change
  const handleTextChange = (newText: string) => {
    setText(newText);
  };

  // Handle voice settings change
  const handleVoiceSettingsChange = (newSettings: Partial<VoiceSettings>) => {
    setVoiceSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Generate speech
  const generateSpeech = async () => {
    if (!text.trim()) {
      toast({
        title: "Text is required",
        description: "Please enter some text to convert to speech.",
        variant: "destructive",
      });
      return;
    }

    try {
      setIsGenerating(true);
      
      const response = await fetch("/api/text-to-speech", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text,
          voiceId: voiceSettings.voiceId,
          speed: 1.0, // Default speed
          pitch: 1.0, // Default pitch
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to generate speech");
      }

      const audioBlob = await response.blob();
      const audioObjectUrl = URL.createObjectURL(audioBlob);
      
      setAudioUrl(audioObjectUrl);
      
      toast({
        title: "Speech generated",
        description: "Your text has been converted to speech successfully.",
      });
    } catch (error: any) {
      console.error("Error generating speech:", error);
      toast({
        title: "Error",
        description: error.message || "Failed to generate speech",
        variant: "destructive",
      });
    } finally {
      setIsGenerating(false);
    }
  };

  // Reset/regenerate
  const handleRegenerate = () => {
    if (audioUrl) {
      URL.revokeObjectURL(audioUrl);
      setAudioUrl(null);
    }
  };

  return (
    <div className="container mx-auto px-4 py-8">
      {/* Page Title */}
      <div className="text-center mb-8">
        <h1 className="text-3xl md:text-4xl font-bold text-gray-800 mb-2">Text to Speech Converter</h1>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Convert your text into natural-sounding speech with customizable voice settings
        </p>
      </div>

      {/* Main Content */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Left Column - Text Input & Controls */}
        <div className="bg-white rounded-xl shadow-md p-6">
          <TextInput
            text={text}
            onTextChange={handleTextChange}
            isGenerating={isGenerating}
            onGenerate={generateSpeech}
          />
          
          <div className="mt-6 space-y-4">
            <h3 className="text-lg font-medium mb-3">Voice Selection</h3>
            
            {loadingVoices ? (
              <div className="space-y-4">
                <Skeleton className="h-10 w-full" />
              </div>
            ) : voicesError ? (
              <div className="text-red-500">
                Failed to load voices. Please refresh the page.
              </div>
            ) : (
              <VoiceControls
                settings={voiceSettings}
                onSettingsChange={handleVoiceSettingsChange}
                voices={voicesData?.voices || []}
              />
            )}
          </div>
        </div>

        {/* Right Column - Audio Player */}
        <AudioPlayer 
          audioUrl={audioUrl} 
          onRegenerate={handleRegenerate}
          isGenerating={isGenerating}
        />
      </div>

      {/* Features Section */}
      <Features />
    </div>
  );
};

export default Home;
